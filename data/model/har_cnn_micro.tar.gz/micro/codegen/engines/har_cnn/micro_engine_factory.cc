// Copyright 2020 The MACE Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This is a generated file. DO NOT EDIT!

#include "micro/codegen/engines/har_cnn/micro_engine_factory.h"


namespace micro {
namespace har_cnn {

namespace {
MaceMicroEngine kMaceMicroEngine;
bool kHasInit = false;
}

extern MaceMicroEngineConfig *GetMicroEngineConfig();

MaceStatus GetMicroEngineSingleton(MaceMicroEngine **engine) {
  MaceStatus status = MACE_SUCCESS;
  if (!kHasInit) {
    MaceMicroEngineConfig *engine_config = GetMicroEngineConfig();
    status = kMaceMicroEngine.Init(engine_config);
  }
  if (status == MACE_SUCCESS) {
    *engine = &kMaceMicroEngine;
  }
  return status;
}

}  // namespace har_cnn
}  // namespace micro
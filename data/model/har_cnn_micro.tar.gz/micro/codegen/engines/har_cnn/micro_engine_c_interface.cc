// Copyright 2020 The MACE Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This is a generated file. DO NOT EDIT!

#include "micro/codegen/engines/har_cnn/micro_engine_c_interface.h"

#include "micro/codegen/engines/har_cnn/micro_engine_factory.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef micro::MaceMicroEngine MaceMicroEngine;
typedef micro::MaceStatus MaceStatus;

void *har_cnn_GetMaceMicroEngineHandle() {
  MaceMicroEngine *micro_engine = NULL;
  micro::har_cnn::GetMicroEngineSingleton(&micro_engine);
  return micro_engine;
}

bool har_cnn_RegisterInputData(void *handle, uint32_t idx,
                                     const void *input_buffer,
                                     const int32_t *input_dims) {
  MaceMicroEngine *micro_engine = static_cast<MaceMicroEngine *>(handle);
  MaceStatus status =
      micro_engine->RegisterInputData(idx, input_buffer, input_dims);
  return (status == micro::MACE_SUCCESS);
}

bool har_cnn_Interpret(void *handle) {
  MaceMicroEngine *micro_engine = static_cast<MaceMicroEngine *>(handle);
  MaceStatus status = micro_engine->Run();
  return (status == micro::MACE_SUCCESS);
}

bool har_cnn_GetInterpretResult(void *handle, const uint32_t idx,
                                      void **output_data,
                                      const int32_t **output_dims,
                                      uint32_t *output_dim_size) {
  MaceMicroEngine *micro_engine = static_cast<MaceMicroEngine *>(handle);
  MaceStatus status = micro_engine->GetOutputData(
      idx, output_data, output_dims, output_dim_size);
  return (status == micro::MACE_SUCCESS);
}

#ifdef __cplusplus
}
#endif
// Copyright 2020 The MACE Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This is a generated file. DO NOT EDIT!

#include "micro/ops/bias_add.h"
#include "micro/ops/reduce.h"
#include "micro/ops/matmul.h"
#include "micro/ops/nhwc/batch_norm.h"
#include "micro/ops/eltwise.h"
#include "micro/ops/softmax.h"
#include "micro/ops/activation.h"
#include "micro/ops/squeeze.h"
#include "micro/ops/expand_dims.h"
#include "micro/ops/nhwc/conv_2d_c4_s4.h"
#include "micro/ops/nhwc/pooling_ref.h"

namespace micro {
namespace har_cnn {

namespace {
  ops::ExpandDimsOp op0;
  ops::Conv2dC4S4Op op1;
  ops::SqueezeOp op2;
  ops::EltwiseOp<mifloat> op3;
  ops::ActivationOp op4;
  ops::ExpandDimsOp op5;
  ops::PoolingRefOp op6;
  ops::SqueezeOp op7;
  ops::BatchNormOp op8;
  ops::ExpandDimsOp op9;
  ops::Conv2dC4S4Op op10;
  ops::SqueezeOp op11;
  ops::EltwiseOp<mifloat> op12;
  ops::ActivationOp op13;
  ops::ExpandDimsOp op14;
  ops::PoolingRefOp op15;
  ops::SqueezeOp op16;
  ops::ExpandDimsOp op17;
  ops::Conv2dC4S4Op op18;
  ops::SqueezeOp op19;
  ops::EltwiseOp<mifloat> op20;
  ops::ActivationOp op21;
  ops::ExpandDimsOp op22;
  ops::PoolingRefOp op23;
  ops::SqueezeOp op24;
  ops::ReduceOp<mifloat> op25;
  ops::MatMulOp op26;
  ops::BiasAddOp op27;
  ops::SoftmaxOp op28;
}  // namespace

framework::Operator *kOpsArray[] = {
  &op0,
  &op1,
  &op2,
  &op3,
  &op4,
  &op5,
  &op6,
  &op7,
  &op8,
  &op9,
  &op10,
  &op11,
  &op12,
  &op13,
  &op14,
  &op15,
  &op16,
  &op17,
  &op18,
  &op19,
  &op20,
  &op21,
  &op22,
  &op23,
  &op24,
  &op25,
  &op26,
  &op27,
  &op28,
};

}  // namespace har_cnn
}  // namespace micro
